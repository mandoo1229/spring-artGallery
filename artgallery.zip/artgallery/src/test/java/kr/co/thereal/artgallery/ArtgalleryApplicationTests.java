package kr.co.thereal.artgallery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtgalleryApplicationTests {

	@Test
	void contextLoads() {
	}

}
